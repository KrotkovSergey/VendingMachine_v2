﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace VendingMachine.Data
{
    public class ClassFrame
    {
        public static Frame frameObj;
    }
}
