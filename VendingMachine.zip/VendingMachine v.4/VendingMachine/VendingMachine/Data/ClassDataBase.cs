﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine.Data
{
    public class ClassDataBase
    {
        public static VendingMachinesEntities dbObject;
    }
}
